﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Form1 : Form
        
    {
        double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void TxtN1_Validated(object sender, EventArgs e)
        {



            if (!double.TryParse(txtN1.Text,out numero1))
            {
                MessageBox.Show("Número 1 inválido!");

            }




        }

        private void TxtN2_Validated(object sender, EventArgs e)
        {

            if (!double.TryParse(txtN2.Text, out numero2))
            {
                MessageBox.Show("Número 2 inválido!");

            }
        }

        private void Btnmais_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtN2.Text, out numero2)&& (double.TryParse(txtN1.Text, out numero1)))
                {

                resultado = numero1 + numero2;
                txtResultado.Text = resultado.ToString();
                }
                else
            {
                MessageBox.Show("Numeros inválidos");
          

            }


        }

        private void Btnmenos_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtN2.Text, out numero2) && (double.TryParse(txtN1.Text, out numero1)))
                {

                resultado = numero1 - numero2;
                txtResultado.Text = resultado.ToString();
            }
            else
            {
                MessageBox.Show("Numeros inválidos");

            }
        }

        private void Btnlimpar_Click(object sender, EventArgs e)
        {
            txtN2.Text = string.Empty;
            txtN1.Text = string.Empty;
            txtResultado.Text = string.Empty;

        }

        private void Btnsair_Click(object sender, EventArgs e)
        {

            System.Windows.Forms.Application.Exit();






        }

        private void Button5_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtN2.Text, out numero2) && (double.TryParse(txtN1.Text, out numero1)))
                {

                resultado = numero1 * numero2;
                txtResultado.Text = resultado.ToString();
            }
            else
            {
                MessageBox.Show("Numeros inválidos");

            }
        }

        private void Button6_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtN2.Text, out numero2) && (double.TryParse(txtN1.Text, out numero1) && numero2 != 0))
                {

                resultado = numero1 / numero2;
                txtResultado.Text = resultado.ToString();
            }
            else
            {
                MessageBox.Show("Numeros inválidos");

            }
        }
    }
}
